<?php

require 'connection.php';
header('Content-Type: application/json');

$cursor = $db->products->find(
    ['quantity' => 0]
);
$result = iterator_to_array($cursor);


$vendor = array();

foreach ($result as $key => $value) {
    $vendor[] = $value['vendor'];
}
$con = json_encode($vendor);

echo "Vendor" . $con;