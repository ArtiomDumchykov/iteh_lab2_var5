<?php require 'connection.php'; ?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Var 5 Mongo</title>
    <script src="js/jquery-3.5.0.min.js"></script>
    <script src="js/ajax.js"></script>
</head>
<body>




<form id="Form3">
    <p><b>перечень производителей, с которыми работает магазин</b></p>
    <p>
        <input type="button" value="Вывести фирмы процессоров" onclick="getModels();">
        <input type="button" value="Данные из LocalStorage" onclick="getLocal3(this);">
        <input type="button" value="Очистить" onclick="$('#result3').html('')">
    </p>
</form>
<ul id="result3"></ul>

    <form action="two.php" method="get">
        <p><b>товары, отсутствующие на складе</b></p>
        <p>
            <input type="submit">
        </p>
    </form>

<form action="three.php" method="get">
    <p><b>товары в выбранном ценовом диапазоне</b></p>
    <input type="range" min="1" max="250" value="1" id="myRange" name="price">
    <p>Значение: <span id="demo"></span></p>
    <p><input type="submit" value="Выбрать"></p>
</form>
<script>
    var slider = document.getElementById("myRange");
    var output = document.getElementById("demo");
    output.innerHTML = slider.value;

    slider.oninput = function() {
        output.innerHTML = this.value;
    }
</script>
</body>
</html>