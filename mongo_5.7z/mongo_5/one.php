<?php

require 'connection.php';
header('Content-Type: application/json');

$cursor = $db->products->find(
    [],[
'projection' => [
'vendor'  => 1
],
    ]
);
$result = iterator_to_array($cursor);


$vendor = array();

foreach ($result as $key => $value) {
    $vendor[] = $value['vendor'];
}
echo json_encode($vendor);