<?php

require 'connection.php';
header('Content-Type: application/json');

$cursor = $db->products->find([
    'price'		=>	array('$lt'	=>	(int)$_GET['price'])
]);
$result = iterator_to_array($cursor);


$vendor = array();

foreach ($result as $key => $value) {
    $vendor[] = $value['name'];
}

echo json_encode($vendor);