function getModels(){
	$.ajax({
		type: "GET",
		url: "one.php",
		dataType: 'json',
		success: function(result){
			$('#result3').html('');
			for (var i = 0; i < result.length; i++) {
				$('#result3').append(
					'<li>'+
					'<td>' + result[i] + '</td>' +
					'</li>'
				);
			}
			localStorage.setItem('form3Result', JSON.stringify(result));
			localStorage.setItem('form3Data', $('#Form3').serialize());
		}
	});
}
function getLocal3(e) {
	$('#result3').html('');
	var currentForm = $(e).parents('form');
	var result = JSON.parse(localStorage.getItem('form3Result'));
	var data = localStorage.getItem('form3Data');
	if (currentForm.serialize() === data) {
		for (var i = 0; i < result.length; i++) {
			$('#result3').append(
				'<li>'+
				'<td>' + result[i] + '</td>' +
				'</li>'
			);
		}
	} else {
		alert("Данные с такими параметрами отсутствуют!");
	}
}